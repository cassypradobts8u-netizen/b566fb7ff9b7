// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("env matrix\n", stdout);
  return lionss_run_workload("env-matrix");
}
