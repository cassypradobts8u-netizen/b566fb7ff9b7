// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("format diff\n", stdout);
  return lionss_run_workload("format-diff");
}
