// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("android x86 64"); }
int main(){
  announce();
  return lionss_run_workload("android-x86-64");
}
