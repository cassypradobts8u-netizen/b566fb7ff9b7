// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("llvm libcxx\n", stdout);
  return lionss_run_workload("llvm-libcxx");
}
