// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("cyclomatic complexity\n", stdout);
  return lionss_run_workload("cyclomatic-complexity");
}
